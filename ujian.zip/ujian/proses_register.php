<?php

	$w = $_POST['a'];
	if(strlen($w) > 20) {
	$hasil = array();
	$hasil["result"]=false;
	$hasil ["message"]="username is required";
	echo json_encode($hasil);
	exit;
	}
	
	$x = $_POST['b'];
	if(empty($x)) {
	$hasil = array();
	$hasil["result"]=false;
	$hasil ["message"]="password is required";
	echo json_encode($hasil);
	exit;
	}
	
	$y = $_POST['c'];
	if(empty($y)) {
	$hasil = array();
	$hasil["result"]=false;
	$hasil ["message"]="email is required";
	echo json_encode($hasil);
	exit;
	}
	
	$z = $_POST['d'];
	if(empty($z)) {
	$hasil = array();
	$hasil["result"]=false;
	$hasil ["message"]="name is required";
	echo json_encode($hasil);
	exit;
	}
	
	
	$p = $_POST['m'];
	if(empty($p)) {
	$hasil = array();
	$hasil["result"]=false;
	$hasil ["message"]="no telepon is required";
	echo json_encode($hasil);
	exit;
	}
	
	$sql = sprintf("SELECT * FROM `coursenetexam` WHERE email = '%s'", $y);
		$dbquery = mysqli_query($koneksi, $sql);
		if( $dbquery->num_rows ){
			$result = false;
			$field = "email";
			$message = "Your email has been taken";
		}
	
	include "db.php";
	
	mysqli_query ($koneksi, "INSERT INTO `coursenetexam`.`register` (`username`, `password`, `email`, `usia`, `id`, phone) VALUES ('$w', MD5('$x'), '$y',
	'$z', NULL, '$p');");
	
	$hasil = array();
	$hasil ["result"]= true;
	echo json_encode($hasil);

?>