<?php
	include "db.php";

	$data = mysqli_query($koneksi, "SELECT * FROM register");
	
	$hasil = array();
	
	while($baris = mysqli_fetch_object($data))
	{
	$hasil[]=$baris;
	}
	
	echo json_encode($hasil);
?>