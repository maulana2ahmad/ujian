<?php
	include "db.php";
		$x = $_GET['id'];
		
		$data = mysqli_query ($koneksi, "SELECT * FROM register WHERE id = $x");
		
		$baris = mysqli_fetch_object($data);
		
		echo json_encode($baris);


?>