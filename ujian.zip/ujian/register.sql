-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Inang: 127.0.0.1
-- Waktu pembuatan: 24 Feb 2019 pada 07.12
-- Versi Server: 5.5.32
-- Versi PHP: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Basis data: `shooterr`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `usia` varchar(100) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=18 ;

--
-- Dumping data untuk tabel `register`
--

INSERT INTO `register` (`username`, `password`, `email`, `usia`, `id`, `phone`) VALUES
('eman', '827ccb0eea8a706c4c34a16891f84e7b', 'eman@gmail.com', 'jl.wargun', 7, '1236597854'),
('ywha', '101a6ec9f938885df0a44f20458d2eb4', 'gahaaha', 'abJ', 8, '3161546464'),
('usere', '827ccb0eea8a706c4c34a16891f84e7b', 'uuuugmail@com', 'jahGHBBbB', 9, '1234569780'),
('passsd', 'ca533fb0d4c9ef97d4026ae934af6696', 'emmm@hmailcom', 'tgkfmvvchhfvffsvfx', 10, '12365478990'),
('ridwanhk', 'e10adc3949ba59abbe56e057f20f883e', 'ridwh@gmail.com', 'jl.wargunnajaja', 11, '12569780489'),
('ridwanhh', 'fe743d8d97aa7dfc6c93ccdc2e749513', 'ridwanhhhh', 'jl.gmail', 12, '123654988998'),
('rumah', '827ccb0eea8a706c4c34a16891f84e7b', 'rumah@gmail.com', 'jlmahababan', 13, '12365478907'),
('tttet', '827ccb0eea8a706c4c34a16891f84e7b', 'rumah@gmail.com', 'jlmbavanvh', 15, '123645789088'),
('mamank', '827ccb0eea8a706c4c34a16891f84e7b', 'mamank@gmail.com', 'gjknlmsngkab', 16, '123645879087'),
('rummah', 'e10adc3949ba59abbe56e057f20f883e', 'rummah@gmail.com', '12345', 17, '123465978087');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
